import matplotlib.pyplot as plt
import numpy as np
import glob

# Список файлов для сравнения (можно изменить на свой)
file_list = ['P2_3.txt', 'P2_10.txt', 'P2_20.txt', 'P2_30.txt', 'f2.txt']  # Добавь сюда нужные файлы

plt.figure(figsize=(10, 6))

for file in file_list:
    try:
        # Загрузка данных
        data = np.loadtxt(file)
        x = data[:, 0]
        y = data[:, 1]

        # Построение графика
        plt.plot(x, y, label=file)
    except Exception as e:
        print(f"Ошибка при обработке {file}: {e}")

# Оформление графика
plt.xlabel('x')
plt.ylabel('y')
plt.title('Сравнение графиков из разных файлов')
plt.legend()
plt.grid()
plt.show()
