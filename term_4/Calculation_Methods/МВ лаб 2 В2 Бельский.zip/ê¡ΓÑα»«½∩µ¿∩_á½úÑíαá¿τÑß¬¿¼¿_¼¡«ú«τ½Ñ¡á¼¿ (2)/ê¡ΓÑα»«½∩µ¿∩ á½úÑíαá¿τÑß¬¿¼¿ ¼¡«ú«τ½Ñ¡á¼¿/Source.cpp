﻿#include <iostream>
#include <vector>
#include <cmath>
#include <iomanip>
#include <fstream>
#include <string>  // Для использования std::to_string

using namespace std;

const int POINTS = 100; // Количество точек для проверки погрешности
const double a = -2, b = 2; // Границы интервала
const double PI = 3.14159265358979323846; // Определяем PI вручную, если M_PI не определён

// Функции
double f1(double x) { return x * x * x * cos(3 * x - 1); } // f1(x) = x³cos(3x - 1)
double f2(double x) { return fabs(5 * cos(3 * x) + 3); } // f2(x) = |5cos(3x) + 3|

// Вычисление разделённых разностей для многочлена Ньютона
vector<double> newtonDividedDifferences(const vector<double>& x, const vector<double>& y)
{
    int n = x.size();
    vector<double> coef(y);
    for (int j = 1; j < n; j++)
    {
        for (int i = n - 1; i >= j; i--)
        {
            // Формула разделённых разностей: f[x_i, ..., x_{i-j}] = (f[x_i, ..., x_{i-j+1}] - f[x_{i-1}, ..., x_{i-j}]) / (x_i - x_{i-j})
            coef[i] = (coef[i] - coef[i - 1]) / (x[i] - x[i - j]);
        }
    }
    return coef;
}

// Вычисление значения интерполяционного многочлена в точке x
double newtonInterpolation(double x, const vector<double>& nodes, const vector<double>& coef)
{
    double result = coef.back();
    for (int i = coef.size() - 2; i >= 0; i--)
    {
        // Формула интерполяционного многочлена Ньютона: P(x) = c_0 + c_1(x - x_0) + c_2(x - x_0)(x - x_1) + ...
        result = result * (x - nodes[i]) + coef[i];
    }
    return result;
}

// Генерация равноотстоящих узлов
vector<double> equidistantNodes(int n) 
{
    vector<double> nodes(n + 1);
    for (int i = 0; i <= n; i++)
    {
        // Формула равноотстоящих узлов: x_i = a + i * (b - a) / n
        nodes[i] = a + i * (b - a) / n;
    }
    return nodes;
}

// Генерация узлов Чебышёва
vector<double> chebyshevNodes(int n)
{
    vector<double> nodes(n + 1);
    for (int i = 0; i <= n; i++) 
    {
        // Формула узлов Чебышёва: x_i = (a + b)/2 + (b - a)/2 * cos((2i + 1) * π / (2(n + 1)))
        nodes[i] = (a + b) / 2.0 + (b - a) / 2.0 * cos((2.0 * i + 1) * PI / (2.0 * (n + 1)));
    }
    return nodes;
}

// Запись точек графика в файл
void writeToFile(const string& filename, const vector<double>& nodes, const vector<double>& coef, double (*f)(double)) 
{
    ofstream file(filename);
    for (int i = 0; i <= POINTS; i++) 
    {
        double xi = a + i * (b - a) / POINTS;
        double yi = newtonInterpolation(xi, nodes, coef);
        file << xi << " " << yi << endl;
    }
    file.close();
}

// Вычисление максимальной погрешности
double computeError(const vector<double>& nodes, const vector<double>& coef, double (*f)(double)) 
{
    double maxError = 0;
    for (int i = 0; i <= POINTS; i++) 
    {
        double xi = a + i * (b - a) / POINTS;
        // Погрешность: |P(x_i) - f(x_i)|
        double error = fabs(newtonInterpolation(xi, nodes, coef) - f(xi));
        if (error > maxError) maxError = error;
    }
    return maxError;
}

int main()
{
    setlocale(LC_ALL, "ru");
    vector<int> ns = { 3, 10, 20, 30 }; // Степени многочленов (добавлено n = 30)

    // Создание файлов с исходными функциями
    ofstream file_f1("f1.txt");
    ofstream file_f2("f2.txt");
    for (int i = 0; i <= POINTS; i++) 
    {
        double xi = a + i * (b - a) / POINTS;
        file_f1 << xi << " " << f1(xi) << endl;
        file_f2 << xi << " " << f2(xi) << endl;
    }
    file_f1.close();
    file_f2.close();

    // Заголовок таблицы погрешностей
    cout << "======================================================================\n";
    cout << "Таблица погрешностей для f1(x) = x³cos(3x - 1)\n";
    cout << "n  | Макс. погрешность (Равноуз.) | Макс. погрешность (Чебышёв)\n";
    cout << "---|-----------------------------|-----------------------------\n";

    // Обработка f1(x)
    for (int n : ns)
    {
        // Генерация узлов
        vector<double> x_eq = equidistantNodes(n);
        vector<double> x_ch = chebyshevNodes(n);

        // Вычисление значений функций в узлах
        vector<double> y1_eq(n + 1), y1_ch(n + 1);
        for (int i = 0; i <= n; i++) 
        {
            y1_eq[i] = f1(x_eq[i]);
            y1_ch[i] = f1(x_ch[i]);
        }

        // Вычисление коэффициентов
        vector<double> coef1_eq = newtonDividedDifferences(x_eq, y1_eq);
        vector<double> coef1_ch = newtonDividedDifferences(x_ch, y1_ch);

        // Запись точек в файлы
        writeToFile("P1_" + to_string(n) + ".txt", x_eq, coef1_eq, f1);
        writeToFile("C1_" + to_string(n) + ".txt", x_ch, coef1_ch, f1);

        // Вывод погрешностей
        cout << setw(2) << n << " | "
            << setw(27) << fixed << setprecision(12) << computeError(x_eq, coef1_eq, f1) << " | "
            << setw(27) << computeError(x_ch, coef1_ch, f1) << endl;
    }

    // Аналогично для f2(x)
    cout << "\n======================================================================\n";
    cout << "Таблица погрешностей для f2(x) = |5cos(3x) + 3|\n";
    cout << "n  | Макс. погрешность (Равноуз.) | Макс. погрешность (Чебышёв)\n";
    cout << "---|-----------------------------|-----------------------------\n";

    for (int n : ns)
    {
        vector<double> x_eq = equidistantNodes(n);
        vector<double> x_ch = chebyshevNodes(n);

        vector<double> y2_eq(n + 1), y2_ch(n + 1);
        for (int i = 0; i <= n; i++)
        {
            y2_eq[i] = f2(x_eq[i]);
            y2_ch[i] = f2(x_ch[i]);
        }

        vector<double> coef2_eq = newtonDividedDifferences(x_eq, y2_eq);
        vector<double> coef2_ch = newtonDividedDifferences(x_ch, y2_ch);

        writeToFile("P2_" + to_string(n) + ".txt", x_eq, coef2_eq, f2);
        writeToFile("C2_" + to_string(n) + ".txt", x_ch, coef2_ch, f2);

        cout << setw(2) << n << " | "
            << setw(27) << computeError(x_eq, coef2_eq, f2) << " | "
            << setw(27) << computeError(x_ch, coef2_ch, f2) << endl;
    }

    return 0;
}